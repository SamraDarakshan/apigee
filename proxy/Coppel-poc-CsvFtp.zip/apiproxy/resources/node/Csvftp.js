  
//Coppel POC
var express = require('express')
var app = express();
var request = require('request');

var url1="http://119.63.131.228:8081/request"
app.get('/', (req, res) => {
  request(url1,{

    },
    function (error, response, body) {
        if(error){
        res.send(error)
        }
       else {
       res.send(body);
       //console.log("Iteration on Rest Api");
       console.log(body);


  }//end else
  }); //end function
});



app.listen(5000, function() {
 console.log('Node HTTP server is listening');
});


