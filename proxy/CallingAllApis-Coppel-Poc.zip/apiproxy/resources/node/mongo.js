
//Coppel POC
var express = require('express')
var app = express()
var mongoose = require('mongoose');
var request = require('request');
var port = 4000
//authorization links
var username = "trainingnaeemmuhammadumer-VV43W7.HIO8IY"
var password = "8fa2497a-06b0-41dc-8b72-63d2c01ba463"
var url = "https://connect.boomi.com/ws/simple/getProducts"
//database
var db = "mongodb://Samra:Samra4!)@ds221416.mlab.com:21416/coppel-poc-rest"

//json to csv
var json2csv = require('json2csv').parse;



//ftp connections

var JSFtp = require("jsftp");


app.get('/', (req, res) => res.send('Hello World!'))

//defining db Schema
var Schema = mongoose.Schema;

var dataSchema = new Schema
({
  "group_id": Number,
 "group_name": String,
 "item_type": String,
 "is_taxable": Boolean,
 "tax_id": Number,
 "tax_name": String,
 "tax_percentage": Number,
 "tax_type": String,
 "item_id": Number,
 "name": String,
 "item_description": String,
 "status": String,
 "pricebook_rate": Number,
 "purchase_rate": Number

});

//compiling our schema into a Model
//globally
var browserModel1 = mongoose.model('product', dataSchema); //create Employees collecton on m lab

//A model is a class with which we construct documents.
//for getting the response
var logs = () => {
        return new Promise((resolve, reject) => {
          request(url,{
              'auth': {
                'user': username,
                'pass': password,
                'sendImmediately': false
              }
            }, function (error, response, body) {
                if(error){
                  reject(error);
                }
            /*    else {
                // res.json(updatedProduct );
                 //console.log(docs);
                 //parse json into js objects
                 var products = JSON.parse(body).products

               //map using for iterating the records
                  var updatedProduct = products.map((item) => {
                   return item;
                 console.log("*****Successfuly Iterated each row*****");
                 resolve(updatedProduct);
         }); //end map
       }//end else */

       var products = JSON.parse(body).products

     //map using for iterating the records
        var updatedProduct = products.map((item) => {
         return item;

       })
       console.log("*****Successfuly Iterated each row*****");
      resolve(updatedProduct);


   }); //end function
 }); //return promise
        }; //end logs function Here

//for saving the response in db
var savedb = (collections) => {
        return new Promise((resolve, reject) => {
        browserModel1.insertMany(collections , function(error, docs) {

       if (error) {
        console.log("error");
      //  res.json(error);
      reject (error);
       } else {
       // res.json(updatedProduct );
        //console.log(docs);
        console.log("*****Successfuly Save to db*****");
        resolve(docs);
} //end else
}); //end funtion insertmany
}); //end return new
} //end savedb


var csvfile = (jsondata) => {
return new Promise((resolve, reject) => {
//  var data = jsondata;
var fields = [
   'group_id',
  'group_name',
  'item_type',
  'is_taxable',
  'tax_id',
  'tax_name',
  'tax_percentage',
  'tax_type',
  'item_id',
  'name',
  'item_description',
   'status',
  'pricebook_rate',
  'purchase_rate',
];
  var opts = { fields };
     json2csv(jsondata, opts,  function(error, csv) {

    //console.log('Csv format')
  //  console.log(csv);
  //  res.send(csv);
    if (error) {
     console.log("error");
    //  res.json(error);
    reject (error);
    } else {
    // res.json(updatedProduct );
    //console.log(csv);
    console.log('*****Successfuly converted to Csv format*****')
     resolve(csv);
   } //end else
}); //end funtion
   }); //end return new
 } //end scsvfile function


var ftpfunc = (csvsata) => {
return new Promise((resolve, reject) => {
  var fs = require("fs");
  var Ftp = new JSFtp({
      host: "12.208.100.69",
   port: 21, // defaults to 21
   user: "user13", // defaults to "anonymous"
   pass: "Cyber@2013" // defaults to "@anonymous"
  });

 // for ftp
  var remote = "/user13/Apigee/csvfile.csv";

   var responseData= Buffer.from( csvdata, 'utf8' );

           Ftp.put(responseData, remote, function(err,file) {
               if (err) {
                   console.error(err);
                   reject (error);
               }
               else {
                   console.log(remote + "*****-Successfuly Uploaded*****");
                   //callback();
                   resolve(file);
               }
           }); //end put
});// end promise
} ; //end ftpfunc


// Calling Api
app.get('/request', async (req, res) => {
  try{

  var updatedPro = await logs();
  console.log(updatedPro );
  res.send(updatedPro);
  var savedataindb = await savedb (updatedPro);
  console.log(savedataindb);
//  res.send(savedataindb);


  var csvcon = await csvfile (updatedPro);
    console.log(csvcon);
    res.send(csvcon);

   var ftpfileupload = await ftpfunc (csvcon);
   console.log(ftpfileupload);


  }
  catch(e){
    console.log(e);
  }

}) //end get

//connecting to db

mongoose.connect(db,{ useNewUrlParser: true }).then(()=> {
    console.log("connected to mongoDB")
  },
  //  app.listen(port, () => console.log(`Example app listening on port ${port}!`))
 (err)=>{
     console.log("err",err);
}
);
/*
mongoose.connect(db function(err) {
 if (err) {
  console.log("error!! " + err)
 } else {
  console.log("COnnection Successfull")
 }
}) */

app.listen(port, () => console.log(`Example app listening on port ${port}!`))
