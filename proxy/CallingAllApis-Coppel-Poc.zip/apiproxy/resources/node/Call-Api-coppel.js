
//Coppel POC
var express = require('express')
var app = express()
var mongoose = require('mongoose');
var request = require('request');
//var port = 4000;

//authorization links
var username = "trainingnaeemmuhammadumer-VV43W7.HIO8IY"
var password = "8fa2497a-06b0-41dc-8b72-63d2c01ba463"
var url = "https://connect.boomi.com/ws/simple/getProducts"

//database
var db = "mongodb://Samra:Samra4!)@ds221416.mlab.com:21416/coppel-poc-rest"

//calling rest api
app.get('/rest', (req, res) => {

request(url,{
    'auth': {
      'user': username,
      'pass': password,
      'sendImmediately': false
    }
  },
  function (error, response, body) {
      if(error){
      res.send(error);
      }
     else {
       var products = JSON.parse(body).products

     //map using for iterating the records
        var updatedProduct = products.map((item) => {
         return item;
          }); //end map
       console.log("*****Successfully Iterated each row*****");
       res.send(updatedProduct);
       console.log(updatedProduct);


}//end else
}); //end function
});

//calling db api from apigee
var ur = "http://samradarakshan-eval-test.apigee.net/coppel/poc1/request"
app.get('/db', (req, res) => {

request(ur,{

  },
  function (error, response, body) {
      if(error){
      res.send(error)
      }
     else {
     res.send(body);
     console.log("In Db body");
     console.log(body);


}//end else
}); //end function
});


//calling csvftp api from apigee
var u = "http://samradarakshan-eval-test.apigee.net/coppel-poc-csvftp"
app.get('/ftp', (req, res) => {

request(u,{
  },
  function (error, response,body) {
      if(error){
      res.send(error)
      }
     else {
     res.send(body);
     console.log("In CsvFtp body");
     console.log(body);

}//end else
}); //end function
});




app.listen(5000, function() {
 console.log('Node HTTP server is listening');
});
