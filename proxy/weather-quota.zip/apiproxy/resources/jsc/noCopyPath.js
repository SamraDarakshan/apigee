// noCopyPath.js
// ------------------------------------------------------------------
//

context.setVariable('target.copy.pathsuffix', false);
