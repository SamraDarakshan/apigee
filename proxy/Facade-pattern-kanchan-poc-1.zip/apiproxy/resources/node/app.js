var express = require('express');
var app = express();

app.get('/', (req, res) => res.send('Coppel-Poc!'))

/*
var request = require('request');
var port = 4000;
var username = "trainingnaeemmuhammadumer-VV43W7.HIO8IY";
var password = "8fa2497a-06b0-41dc-8b72-63d2c01ba463";
var url = "https://connect.boomi.com/ws/simple/getProducts";






app.get('/request', (req, res) => {
    request(url,{
        'auth': {
          'user': username,
          'pass': password,
          'sendImmediately': false
        }
      }, function (error, response, body) {
          if(error){
              res.send(error);
              return;
          }
          var products = JSON.parse(body).products;
 
           var updatedProduct = products.map((item) => {

          });
 
            res.send(updatedProduct);
        }  );


}); */

//app.listen(port, () => console.log(`Example app listening on port ${port}!`));
app.listen(5000, function() {
 console.log('Node HTTP server is listening');
});
