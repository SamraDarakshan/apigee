
//Coppel POC
var express = require('express')
var app = express()
//var mongoose = require('mongoose');
var request = require('request');

var url1="http://samradarakshan-eval-test.apigee.net/coppel-poc-authorization"
app.get('/rest', (req, res) => {
  request(url1,{

    },
    function (error, response, body) {
        if(error){
        res.send(error)
        }
       else {
       res.send(body);
       console.log("Iteration on Rest Api");
       console.log(body);


  }//end else
  }); //end function
});


//calling db api from apigee
var url2 = "http://samradarakshan-eval-test.apigee.net/coppel/pocdb/db"
app.get('/db', (req, res) => {

request(url2,{

  },
  function (error, response, body) {
      if(error){
      res.send(error)
      }
     else {
     res.send(body);
     console.log("In Db body");
     console.log(body);


}//end else
}); //end function
});


//calling csvftp api from apigee
var url3 = "http://samradarakshan-eval-test.apigee.net/coppel-poc-csvftp"
app.get('/ftp', (req, res) => {

request(url3,{
  },
  function (error, response,body) {
      if(error){
      res.send(error)
      }
     else {
     res.send(body);
     console.log("In CsvFtp body");
     console.log(body);

}//end else
}); //end function
});



//var url4="http://119.63.131.228:8081/product"

var url4 = "https://samradarakshan-eval-test.apigee.net/coppel-poc-complete"
app.get('/all', (req, res) => {
  request(url4,{

    },
    function (error, response, body) {
        if(error){
        res.send(error)
        }
       else {
       res.send(body);
       //console.log("Iteration on Rest Api");
       console.log(body);


  }//end else
  }); //end function
});
/*
app.get('/all', (req, res) => {
    // construct urls

  var p1 = rp(url1);
  var p2 = rp(url2);
  var p3 = rp(url3);
    Promise.all([p1,p2]).then(results => {
        // construct full response from the results array
        //req.send(fullResponse);
        res.send("Successfully done everything");
    }).catch(err => {
        res.status(500).send(err.message);
    });

});

*/


app.listen(5000, function() {
 console.log('Node HTTP server is listening');
});


