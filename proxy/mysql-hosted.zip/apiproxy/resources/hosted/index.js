/*var http = require ("http");
var mysql      = require('mysql');
var connection = mysql.createConnection({
 host: "mudb.learn.mulesoft.com",
	port: "3306",
	user: "mule",
	password: "mule",
	database: "training"
});


/*http.createServer(function (req, res) {
  fs.readFile(__dirname + '/demofile1.html','utf8', function(err, data) {
   // res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(data);
    res.end();
  }); 
//connection.connect();
connection.connect(function(err,res) {
  if (err) throw err;
  console.log("Connected!");
  res.write('connected');
  connection.end();
}
);
/*connection.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
  if (error) throw error;
  console.log('The solution is: ', results[0].solution);
}); */
var mysql      = require('mysql');
var mysqlConnector = require('volos-mysql');
var http = require('http');
var restMap = require('./queryToRestMap');
 
var profile = {
    user: 'mule',
    password: 'mule',
    host: "mudb.learn.mulesoft.com",
    port: "3306"
};
 
 var mysqlConnectorObject = new mysqlConnector.MySqlConnector({"profile": profile, "restMap": restMap});
 
var svr = http.createServer(function (req, resp) {
    mysqlConnectorObject.dispatchRequest(req, resp);
    resp.write("connected");
});
 
svr.listen(9089, function () {
    mysqlConnectorObject.initializePaths(restMap);
    console.log(mysqlConnectorObject.applicationName + ' node server is listening');
});

