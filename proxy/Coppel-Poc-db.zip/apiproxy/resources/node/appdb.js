
var express = require('express')
var mongoose = require('mongoose');
var date = require('date-and-time');
var app = express()
//var bodyParser = require('body-parser')
var request = require('request');
//var port = 4000
var username = "trainingnaeemmuhammadumer-VV43W7.HIO8IY";
var password = "8fa2497a-06b0-41dc-8b72-63d2c01ba463";
var url = "https://connect.boomi.com/ws/simple/getProducts";
//var db= "mongodb://Samra:Samra4!)@ds145573.mlab.com:45573/demodb"
var db = "mongodb://Samra:Samra4!)@ds221416.mlab.com:21416/coppel-poc-rest";

app.get('/db', function(req, res) {
res.send("Connected with database");

/*
mongoose.connect(db,{ useNewUrlParser: true }).then(()=> {
    console.log("*****Successfully Connected with Database*****")
  },

 (err)=>{
     console.log("err",err);
}
);*/
mongoose.connect(db, function(err) {
 if (err) {
  console.log("error!! " + err);
 } else {
  console.log("COnnection Successfull");
 }
});
 // this will not show you can give multiple output you can put above only one can run at a time
});

/*    useMongoClient: true,
    autoIndex: false, // Don't build indexes
    reconnectTries: 100, // Never stop trying to reconnect
    reconnectInterval: 500, // Reconnect every 500ms
    poolSize: 10, // Maintain up to 10 socket connections
    // If not connected, return errors immediately rather than waiting for reconnect
    bufferMaxEntries: 0
  }; */
//app.use(bodyParser.urlencoded({ extended: false }));
//app.use(bodyParser.json());

//defining Schema
var Schema = mongoose.Schema;

var dataSchema = new Schema
 ({
  "group_id": Number,
 "group_name": String,
 "item_type": String,
 "is_taxable": Boolean,
 "tax_id": Number,
 "tax_name": String,
 "tax_percentage": Number,
 "tax_type": String,
 "item_id": Number,
 "name": String,
 "item_description": String,
 "status": String,
 "pricebook_rate": Number,
 "purchase_rate": Number

});

//compiling our schema into a Model

//globally
var browserModel1 = mongoose.model('product', dataSchema);

//app.get('/', (req, res) => res.send('Hello World!'))


  app.get('/request', (req, res) => {
      request(url,{
          'auth': {
            'user': username,
            'pass': password,
            'sendImmediately': false
          }
        }, function (error, response, body) {
            if(error){
                res.send(error)
                return
            }
            var products = JSON.parse(body).products
          //  console.log(products[0])
          //withoutloop
            //res.send(body);// total 4 rows
             var updatedProduct = products.map((item) => {
               //console.log(item.item_id);
              //console.log(item);
            //  res.send(item.item_id);
              return item;
          //
            })


           //console.log(updatedProduct.item_id);
           //res.send(updatedProduct[0].item_id);
         //res.send(updatedProduct);

//save to db
  //var newBrowser1 = new browserModel1();
browserModel1.insertMany(updatedProduct , function(error, docs) {

  if (error) {
   console.log("insert error");
   res.json(error);
  } else {
  // res.json(updatedProduct );
   console.log(docs);
   console.log("Save to db");
   res.send("save to db");
 }
});
/*
updatedProduct.forEach(function (item) {


  var newBrowser1 = new browserModel1(item);

        newBrowser1.save(function(err,res) {
         if (err) {
          console.log("insert error");
          res.json(err);
         } else {
         // res.json(updatedProduct );
          console.log(res);
          console.log("Save to db");
         //res.send(newInsteredValue);

          //resolve

         }


    });
}); */

       });
})
/*
          app.post('/request', (req, res) => {
          , function (error, response, body) {
                    if(error){
                        res.send(error)
                        return
                    }
                    var products = JSON.parse(body).products
                     var updatedProduct = products.map((item) => {
                      return item;
                  //
                    })
                    res.send(updatedProduct);
                  }
//db.product.save(updatedProduct);
 //res.send(db.product.insertMany(updatedProduct);
  /*  app.post('/response', function(req, res) {
     console.log("inside post");
     var newBrowser1 = new browserModel1();
           newBrowser1.save(function(err,updatedProduct ) {
            if (err) {
             console.log("insert error");
             res.json(err);
            } else {
             res.json(updatedProduct );
             console.log(updatedProduct );
            //res.send(newInsteredValue);

             //resolve

            }
          })
        }); */




//app.use(express.bodyParser());

//db

//var db= "mongodb://Samra:Samra4!)@ds145573.mlab.com:21416/coppel-poc-rest"




/*
mongoose.connect(db,options).then(
  ()=>{
    console.log("connected to mongoDB")},
  //  app.listen(port, () => console.log(`Example app listening on port ${port}!`))

 (err)=>{
     console.log("err",err);
}

); */

//connecting to db


//app.listen(port, () => console.log(`Example app listening on port ${port}!`))
app.listen(5000, function() {
 console.log('Node HTTP server is listening');
});
