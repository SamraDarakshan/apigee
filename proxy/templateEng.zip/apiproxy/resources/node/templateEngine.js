/*var http = require('http');
var fs = require('fs');
http.createServer(function (req, res) {
  fs.readFile('demofile1.html', function(err, data) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(data);
    res.end();
  });
}).listen(8080); */

/*app.set('views', path.join(__dirname, 'views'))

  express.static(path.join(__dirname, 'public')), */
/*
var express = require ('express');
var http = require('http');
var fs = require('fs');
const path = require('path');
//var aws = require('aws-sdk');
//var csv = require('csvtojson');
var http = require('http');
var apigee = require('apigee-access');

var app = express();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
//app.use('/',express.static('views'));
//using middle ware
app.get(express.static('./views'));
app.get(express.static('./public'));

///----- afterrr a lot of searching
/*app.set('views', path.join(__dirname, 'views'));

express.static(path.join(__dirname, 'public')); */
/*

app.get('/server',function(req,res){
 res.sendFile('/httpcreate.js');
});


/*app.get('/server',function(req,res){
 res.sendFile('/httpcreate.js');
});*/
/*
///nowwww using readfile
app.get('/server',fs.readFile('httpcreate.js') , function(err, data) {
 //fs.readFile('httpcreate.js', function(err, data) {
   // res.writeHead(200, {'Content-Type': 'text/html'});
    //res.write(data);
    //res.end();
    res.send(data)
  });
  
  
  app.get('/form',function(req,res){
 res.sendFile(__dirname + '/formGet.js');
});




//querystrings
 app.get('/query',function(req,res){
   console.log(req.query);
   res.send(req.query);
 });

app.get("/products/:productId", function(req, res){
 res.send("Requested " + req.params.productId );
});
 //res.render('profile',{qs: req.query}); we can give this qs in that file


app.get('/profile/:name',function(req,res){
//res.send('you are viewing the profile of' + req.params.name );// withou ejs
//we use render for view an ejs files
//res.render('prof'); // calling view file with ejs
//res.render('profile'); // calling view file with ejs
//res.send(req.params.name);
var info ={age:23, job:'software eng', hobbies: ['driving','reading','listening music']};
res.render('profile', {person: req.params.name, data:info});
//res.render('profile', {person: req.params.name});
});

app.get('/prof/:name',function(req,res){
res.render('prof', {person: req.params.name});
})

app.listen(3000);
 console.log("Example app listening at 3000"); 
 */
 
 var express = require ('express');


var app = express();

app.set('view engine', 'ejs');
app.use('/',express.static('views')); //it is ot working here cx it directly eject i think 

//we cant give like router in router we can give path and that require varibale but here we cant
//app.get('/',function(req,res){
// res.sendFile(__dirname + '/formGet.html');


//querystrings
 app.get('/query',function(req,res){
   console.log(req.query);
   res.send(req.query);
 });

 //res.render('profile',{qs: req.query}); we can give this qs in that file
//});

app.get('/profile/:name',function(req,res){
//res.send('you are viewing the profile of' + req.params.name );// withou ejs
//we use render for view an ejs files
//res.render('prof'); // calling view file with ejs
//res.render('profile'); // calling view file with ejs
//res.send(req.params.name);
var info ={age:23, job:'software eng', hobbies: ['driving','reading','listening music']};
res.render('profile', {person: req.params.name, data:info});
//res.render('profile', {person: req.params.name});
});
/*
app.get('/prof/:name',function(req,res){
res.render('prof', {person: req.params.name});
});
app.listen(3000);
 console.log("Example app listening at 3000");

http.createServer(function (req, res) {
  fs.readFile(__dirname + '/demofile.txt','utf8', function(err, data) {
   // res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(data);
    res.end();
  });
}).listen(8080); */
