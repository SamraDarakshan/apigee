
<!DOCTYPE HTML>
<html>
<body>
<script>
<!-- when ever you hit the submit button this will call-->
<form action= "http://127.0.0.1:8081/process_get"  method="GET">

First Name: <input type="text" name="first_name"> <br/>

Last Name: <input type="text" name="last_name"> <br/>
<input type="submit" value="submit">

</form>
</script>
</body>
</html>
