/*
 * Test the mock back end that we have implemented in testserver.js
 */

var assert = require('assert');
var childProcess = require('child_process');
var path = require('path');

var requestModule = require('request');

var BASE = 'https://mocktarget.apigee.net/json';

var request = requestModule.defaults({
  json: true
});

describe('Test mock back end', function() {
  var server;

  before(function(done) {
    server = childProcess.fork(path.join(__dirname, 'fixtures/testserver.js'));
    setTimeout(function() {
      done();
    }, 1000);
  });
  after(function() {
    server.kill();
  });

  it('Get org list', function(done) {
    request.get(BASE + '/o', function(err, resp, body) {
      assert(!err);
      done();
    });
  });

  it('Get good org', function(done) {
    request.get(BASE + '/o/test', function(err, resp, body) {
      assert(!err);
      assert.equal(body.name, 'test');
      done();
    });
  });
  it('Get bad org', function(done) {
    request.get(BASE + '/o/nonexistant', function(err, resp, body) {
      assert(!err);
      assert.equal(resp.statusCode, 404);
      done();
    });
  });

  it('Get test environment', function(done) {
    request.get(BASE + '/o/test/e/test', function(err, resp, body) {
      assert(!err);
      assert.equal(body.name, 'test');
      done();
    });
  });
  it('Get prod environment', function(done) {
    request.get(BASE + '/o/test/e/prod', function(err, resp, body) {
      assert(!err);
      assert.equal(body.name, 'prod');
      done();
    });
  });
  it('Get bad environment', function(done) {
    request.get(BASE + '/o/test/e/BAD', function(err, resp, body) {
      assert(!err);
      assert.equal(resp.statusCode, 404);
      done();
    });
  });

  it('Get default virtual host', function(done) {
    request.get(BASE + '/o/test/e/test/virtualhosts/default', function(err, resp, body) {
      assert(!err);
      assert.equal(body.name, 'default');
      assert.equal(body.port, 80);
      done();
    });
  });
  it('Get secure virtual host', function(done) {
    request.get(BASE + '/o/test/e/test/virtualhosts/secure', function(err, resp, body) {
      assert(!err);
      assert.equal(body.name, 'secure');
      assert.equal(body.port, 443);
      done();
    });
  });
  it('Get bad virtual host', function(done) {
    request.get(BASE + '/o/test/e/test/virtualhosts/BAD', function(err, resp, body) {
      assert(!err);
      assert.equal(resp.statusCode, 404);
      done();
    });
  });

  it('Get no APIs', function(done) {
    request.get(BASE + '/o/test/apis', function(err, resp, body) {
      assert(!err);
      assert.equal(resp.statusCode, 200);
      assert.equal(body.length, 0);
      done();
    });
  });
  it('Add API', function(done) {
    var api = { name: 'api1'};
    request.post(BASE + '/o/test/apis', { body: api }, function(err, resp, body) {
      assert(!err);
      assert.equal(resp.statusCode, 201);
      done();
    });
  });
  it('Check API', function(done) {
    request.get(BASE + '/o/test/apis/api1', function(err, resp, body) {
      assert(!err);
      assert.equal(resp.statusCode, 200);
      done();
    });
  });

  it('Add Revision', function(done) {
    done();
  });
});
