
//Coppel POC
var express = require('express');
var app = express();
var mongoose = require('mongoose');
var request = require('request');
//var port = 4000;

//authorization links
var username = "trainingnaeemmuhammadumer-VV43W7.HIO8IY";
var password = "8fa2497a-06b0-41dc-8b72-63d2c01ba463";
var url = "https://connect.boomi.com/ws/simple/getProducts";

//database
var db = "mongodb://Samra:Samra4!)@ds221416.mlab.com:21416/coppel-poc-rest";

//json to csv
var json2csv = require('json2csv').parse;

//fields for csv
var fields = [
   'group_id',
  'group_name',
  'item_type',
  'is_taxable',
  'tax_id',
  'tax_name',
  'tax_percentage',
  'tax_type',
  'item_id',
  'name',
  'item_description',
   'status',
  'pricebook_rate',
  'purchase_rate',
];
var opts = { fields };

//ftp connections

var JSFtp = require("jsftp");
 var fs = require("fs");
 var Ftp = new JSFtp({
     host: "12.208.100.69",
  port: 21, // defaults to 21
  user: "user13", 
  pass: "Cyber@2013"
 });

app.get('/', (req, res) => res.send('Hello World!'));

//defining db Schema
var Schema = mongoose.Schema;

var dataSchema = new Schema
({
  "group_id": Number,
 "group_name": String,
 "item_type": String,
 "is_taxable": Boolean,
 "tax_id": Number,
 "tax_name": String,
 "tax_percentage": Number,
 "tax_type": String,
 "item_id": Number,
 "name": String,
 "item_description": String,
 "status": String,
 "pricebook_rate": Number,
 "purchase_rate": Number,


});

//compiling our schema into a Model
//A model is a class with which we construct documents.
var browserModel1 = mongoose.model('product', dataSchema); //create products collecton on m lab


//function for getting the response
var logs = () => {
        return new Promise((resolve, reject) => {
          request(url,{
              'auth': {
                'user': username,
                'pass': password,
                'sendImmediately': false
              }
            }, function (error, response, body) {
                if(error){
                  reject(error);
                }
               else {
                 var products = JSON.parse(body).products;

               //map using for iterating the records
                  var updatedProduct = products.map((item) => {
                   return item;
                    }); //end map
                 console.log("*****Successfully Iterated each row*****");
                 resolve(updatedProduct);

       }//end else
   }); //end function
 }); //return promise
        }; //end logs function Here

//function for saving the response in db
var savedb = (collections) => {
        return new Promise((resolve, reject) => {
        browserModel1.insertMany(collections , function(error, docs) {

       if (error) {
        console.log("error");
      reject (error);
       } else {
        console.log("*****Successfully Save to db*****");
        resolve(docs);
} //end else
}); //end funtion insertmany
}); //end return new
}; //end savedb

//function for csv and ftp
var csvftp = (jsondata) => {
return new Promise((resolve, reject) => {
try {

//json to csv
  var csv = json2csv(jsondata, opts);
  console.log('*****Converted JSON to CSV format*****');
  console.log(csv);

//ftp connection
   var remote = "/user13/Apigee/itemId_currentDate.csv";
   var responseData= Buffer.from( csv, 'utf8' );
           Ftp.put(responseData, remote, function(err) {
               if (err) {
                  console.log("Error in ftp");
                   console.error(err);
               }
               else {
                   console.log(remote + " - Successfully Uploaded CSV file");
                   resolve("*****Uploaded Successfully*****");
               }

           });
          Ftp.close();

}

 catch(e)  {
  coneole.log("Error in csvftp method");
  console.log(e);
  reject(e);
}

}); //end new promise
}; //end csvftp

// Calling Api
//main method
app.get('/request', async (req, res, next) => {
  try{

  //calling response funcion
  var updatedPro = await logs();
  console.log(updatedPro );
  res.send(updatedPro);

    //calling savedb function
  var savedataindb = await savedb (updatedPro);
  console.log(savedataindb);

     //calling csvftp function
   var csvdatasavetoftp = await csvftp (updatedPro);
    console.log(csvdatasavetoftp);
    res.send(csvdatasavetoftp);

  }

  catch(e){
    return next();
    console.log(e);
    console.log("Error in main");
  }

}) //end  main get

//connecting to db
mongoose.connect(db,{ useNewUrlParser: true }).then(()=> {
    console.log("*****Successfully Connected with Database*****")
  },

 (err)=>{
     console.log("err",err);
}
);

//app.listen(port, () => console.log(`Coppel-poc API listening on port ${port}!`));
app.listen(5000, function() {
 console.log('Node HTTP server is listening');
});
