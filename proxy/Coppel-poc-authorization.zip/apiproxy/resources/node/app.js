var express = require('express')
var app = express();

var request = require('request');
//var port = 7000
var username = "trainingnaeemmuhammadumer-VV43W7.HIO8IY"
var password = "8fa2497a-06b0-41dc-8b72-63d2c01ba463"
var url = "https://connect.boomi.com/ws/simple/getProducts"



//app.get('/', (req, res) => res.send('Hello World!'))

//promise
//.then //async
app.get('/', (req, res) => {
    request(url,{
        'auth': {
          'user': username,
          'pass': password,
          'sendImmediately': false
        }
      }, function (error, reponse, body) {
          if(error){
              res.send(error)
              return
          }
          var products = JSON.parse(body).products
        //  console.log(products[0])
        //withoutloop
          //res.send(body);// total 4 rows
           var updatedProduct = products.map((item) => {
             //console.log(item.item_id);
            //console.log(item);
          //  res.send(item.item_id);
            return item;
        //
          })
           //console.log(updatedProduct.item_id);

           //res.send(updatedProduct[0].item_id);
         //res.send(updatedProduct);
          //res.send(products[0])
            res.send(updatedProduct);
            console.log(updatedProduct);
        }  );


})

app.listen(5000, function() {
 console.log('Node HTTP server is listening');
});

