<h1>Nodejs Rest API Example Using ExpressJS and Mysql</h1>
I have created simple example to create RESTFul api for crud operation using mysql database.I have added following features into this source code,
<ul>
<li>Add Record using rest call into mysql database</li>
<li>Edit Record using rest call into mysql database</li>
<li>Delete Record using rest call into mysql database</li>
<li>Featch records using rest call into mysql database</li>
</ul>

# how to create table in db
You need to craete 'test' database into mysql and import customer.sql table into your mysql database.

# How to run nodejs application
<p>copy index.js and package.json file into your nodejs project folder,</p>
<p>Open command line and cd to your above nodejs project folder</p>
<p>run 'npm install'</p>
<p>run 'node index.js'</p>
